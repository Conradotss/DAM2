/*
 * Index
 * @version: 1.3.0
 * @author: HtmlStream
 * @license: Licensed under MIT (https://preline.co/docs/license.html)
 * Copyright 2023 Htmlstream
 */

import './components/hs-accordion';
import './components/hs-collapse';
import './components/hs-dropdown';
import './components/hs-overlay';
import './components/hs-remove-element';
import './components/hs-scrollspy';
import './components/hs-tabs';
import './components/hs-tooltip';
